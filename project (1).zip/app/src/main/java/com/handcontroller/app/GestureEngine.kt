package com.handcontroller.app

import android.content.Context
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class GestureEngine {

    private enum class Pose { NONE, PALM, FIST, POINT, PEACE, THUMB, PINCH }

    private class Motion(val t: Long, val cum: Float, val wx: Float, val wy: Float)
    private class PtSample(val t: Long, val x: Float, val y: Float)

    private companion object {
        const val OPEN_T = 1.45f      // इससे ज़्यादा = उँगलियाँ खुली
        const val CURL_T = 1.25f      // इससे कम = उँगलियाँ मुड़ी
        const val FAST_MS = 900L      // मुड़ने/खुलने की अधिकतम अवधि
        const val SWEEP_DEG = 85f     // हाथ घुमाने का कम से कम कोण
        const val SWEEP_WINDOW = 1200L
        const val COOLDOWN = 1500L    // दो स्क्रॉल के बीच का अंतर
    }

    // CameraService इसे सेट करता है (चौड़ाई / ऊँचाई)
    @Volatile
    var aspect = 0.75f

    private var pose = Pose.NONE
    private var poseSince = 0L
    private var fired = false
    private var lastAction = 0L
    private var lastScroll = 0L

    // पॉइंटर
    private var px = 0.5f
    private var py = 0.5f
    private var lastPointT = 0L
    private var pointerShown = false
    private val ptHist = ArrayList<PtSample>()

    // हाथ की दिशा (कोण) का इतिहास
    private var haveAng = false
    private var lastAng = 0f
    private var cumAng = 0f
    private val motion = ArrayList<Motion>()

    // उँगलियों की हालत: -1 अनजान, 0 खुली, 1 मुड़ी
    private var curState = -1
    private var lastOpenT = 0L
    private var lastCurledT = 0L
    private var curlEnteredAt = 0L
    private var curlByGesture = false
    private var tainted = false

    fun noHand() {
        pose = Pose.NONE
        haveAng = false
        motion.clear()
        ptHist.clear()
        curState = -1
        tainted = false
        if (pointerShown) {
            HandControlService.instance?.hidePointer()
            pointerShown = false
        }
    }

    private fun d(a: NormalizedLandmark, b: NormalizedLandmark): Float =
        hypot((a.x() - b.x()) * aspect, a.y() - b.y())

    // चारों उँगलियों के (सिरा-कलाई दूरी) / (जड़-कलाई दूरी) का औसत
    private fun curlRatio(l: List<NormalizedLandmark>): Float {
        val w = l[0]
        var s = 0f
        for (i in 0..3) {
            val tip = l[8 + 4 * i]
            val mcp = l[5 + 4 * i]
            s += d(tip, w) / max(d(mcp, w), 0.001f)
        }
        return s / 4f
    }

    // हथेली किस दिशा में है: 90 = ऊपर, 0 = दाएँ, 180 = बाएँ
    private fun pointAngle(l: List<NormalizedLandmark>): Float {
        val dx = (l[9].x() - l[0].x()) * aspect
        val dy = -(l[9].y() - l[0].y())
        return Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
    }

    private fun classify(l: List<NormalizedLandmark>): Pose {
        val w = l[0]
        val idx = d(l[8], w) > d(l[6], w)
        val mid = d(l[12], w) > d(l[10], w)
        val ring = d(l[16], w) > d(l[14], w)
        val pnk = d(l[20], w) > d(l[18], w)
        val thumbOut = d(l[4], l[17]) > d(l[3], l[17]) * 1.15f
        val size = d(l[0], l[9])
        val pinch = d(l[4], l[8]) < size * 0.3f && d(l[8], w) > size
        val thumbUp = thumbOut && l[4].y() < l[3].y() && l[3].y() < l[2].y()

        return when {
            pinch -> Pose.PINCH
            idx && mid && ring && pnk -> Pose.PALM
            !idx && !mid && !ring && !pnk -> if (thumbUp) Pose.THUMB else Pose.FIST
            idx && !mid && !ring && !pnk -> Pose.POINT
            idx && mid && !ring && !pnk -> Pose.PEACE
            else -> Pose.NONE
        }
    }

    private fun fire(now: Long) {
        fired = true
        lastAction = now
    }

    private fun fireScroll(now: Long) {
        lastScroll = now
        fire(now)
    }

    fun update(l: List<NormalizedLandmark>, now: Long) {
        val svc = HandControlService.instance ?: return

        val newPose = classify(l)
        if (newPose != pose) {
            pose = newPose
            poseSince = now
            fired = false
        }
        val size = d(l[0], l[9])
        val ratio = curlRatio(l)
        val pointing = pose == Pose.POINT || pose == Pose.PINCH
        val heldPose = now - poseSince

        // ---------- हाथ की दिशा का इतिहास ----------
        val ang = pointAngle(l)
        if (!haveAng) {
            haveAng = true
            lastAng = ang
            cumAng = ang
        } else {
            var dl = ang - lastAng
            while (dl > 180f) dl -= 360f
            while (dl < -180f) dl += 360f
            cumAng += dl
            lastAng = ang
        }
        motion.add(Motion(now, cumAng, l[0].x() * aspect, l[0].y()))
        while (motion.isNotEmpty() && now - motion[0].t > SWEEP_WINDOW) motion.removeAt(0)

        var mn = cumAng
        var mx = cumAng
        var minX = motion[0].wx
        var maxX = motion[0].wx
        var minY = motion[0].wy
        var maxY = motion[0].wy
        for (m in motion) {
            mn = min(mn, m.cum)
            mx = max(mx, m.cum)
            minX = min(minX, m.wx)
            maxX = max(maxX, m.wx)
            minY = min(minY, m.wy)
            maxY = max(maxY, m.wy)
        }
        val angRange = mx - mn
        val drift = hypot(maxX - minX, maxY - minY)

        // ---------- पॉइंटर ----------
        if (pose == Pose.POINT) {
            val tx = ((l[8].x() - 0.15f) / 0.7f).coerceIn(0f, 1f)
            val ty = ((l[8].y() - 0.15f) / 0.7f).coerceIn(0f, 1f)
            px += (tx - px) * 0.35f
            py += (ty - py) * 0.35f
            svc.movePointer(px, py)
            pointerShown = true
            lastPointT = now
            ptHist.add(PtSample(now, px, py))
            while (ptHist.isNotEmpty() && now - ptHist[0].t > 600) ptHist.removeAt(0)
        } else if (pose != Pose.PINCH && pointerShown && now - lastPointT > 350) {
            svc.hidePointer()
            pointerShown = false
        }

        // पॉइंटर / पीस वाली हालत में बनी "मुड़ी उँगलियाँ" स्क्रॉल नहीं बनेंगी
        if ((pointing || pose == Pose.PEACE) && heldPose > 250) tainted = true

        // ---------- उँगलियों की हालत ----------
        val newState = when {
            ratio > OPEN_T -> 0
            ratio < CURL_T -> 1
            else -> curState
        }
        if (ratio > OPEN_T) lastOpenT = now
        if (ratio < CURL_T) lastCurledT = now

        val canScroll = now - lastScroll > COOLDOWN
        var scrolled = false

        // ---------- 1) हाथ घुमाना (दाएँ <-> बाएँ) ----------
        if (canScroll && !pointing && motion.size >= 4) {
            val ccw = cumAng - mn >= SWEEP_DEG
            val cw = mx - cumAng >= SWEEP_DEG
            if (ccw || cw) {
                val isCcw = if (ccw && cw) (cumAng - mn) >= (mx - cumAng) else ccw
                val swap = svc.getSharedPreferences("hc", Context.MODE_PRIVATE)
                    .getBoolean("swap", false)
                val left = if (swap) !isCcw else isCcw
                svc.swipeH(left)
                fireScroll(now)
                motion.clear()
                scrolled = true
            }
        }

        // ---------- 2) उँगलियाँ मोड़ना / खोलना (ऊपर-नीचे वीडियो) ----------
        if (!scrolled && newState != curState) {
            val prevState = curState
            curState = newState
            val upright = lastAng in 35f..145f
            val steady = angRange < 45f && drift < size * 1.2f

            if (newState == 1) {
                curlEnteredAt = now
                curlByGesture = false
                tainted = pointing && heldPose > 250
                // उँगलियाँ जल्दी से मुड़ीं = पिछला वीडियो
                if (prevState == 0 && now - lastOpenT <= FAST_MS &&
                    canScroll && !pointing && !tainted && upright && steady
                ) {
                    svc.swipe(false)
                    fireScroll(now)
                    curlByGesture = true
                }
            } else if (newState == 0) {
                if (prevState == 1) {
                    val curledHeld = now - curlEnteredAt
                    val need = if (curlByGesture) 1500L else 350L
                    val fast = now - lastCurledT <= FAST_MS
                    // मुड़ा हाथ जल्दी से खुला = अगला वीडियो
                    if (fast && canScroll && !tainted && upright && steady && curledHeld >= need) {
                        svc.swipe(true)
                        fireScroll(now)
                    }
                }
                tainted = false
                curlByGesture = false
            }
        }

        // ---------- रोककर रखने वाले / एक बार वाले इशारे ----------
        val held = now - max(poseSince, lastAction)
        val quiet = now - lastScroll > 2000
        if (!fired && now - lastAction > 900) {
            when (pose) {
                Pose.PINCH -> if (held > 150) {
                    // पिंच से ठीक पहले वाली पॉइंटर जगह पर टैप
                    val target = poseSince - 120
                    var tx = px
                    var ty = py
                    for (s in ptHist) {
                        if (s.t <= target) {
                            tx = s.x
                            ty = s.y
                        }
                    }
                    svc.tapAt(tx, ty)
                    fire(now)
                }
                Pose.THUMB -> if (held > 1200 && quiet) { svc.doubleTapCenter(); fire(now) }
                Pose.FIST -> if (held > 1500 && quiet && ratio < 1.0f) { svc.goBack(); fire(now) }
                Pose.PEACE -> if (held > 1000 && quiet) { svc.goHome(); fire(now) }
                Pose.PALM -> if (held > 2500 && quiet) { svc.tapAt(0.5f, 0.5f); fire(now) }
                else -> {}
            }
        }
    }
}

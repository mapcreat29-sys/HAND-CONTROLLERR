package com.handcontroller.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val tv = TextView(this)
        tv.textSize = 16f
        tv.text = "Hand Controller\n\n" +
            "पहले ये करें:\n" +
            "1) नीचे बटन 2 दबाकर App info में ऊपर दाईं ⋮ से \"Allow restricted settings\" चुनें (अगर दिखे)।\n" +
            "2) बटन 1 दबाकर Accessibility में Hand Controller को चालू करें।\n" +
            "3) बटन 3 दबाएँ और कैमरा permission दें।\n" +
            "4) फ़ोन को सामने टिकाकर रखें, ताकि फ्रंट कैमरे को हाथ दिखे।\n\n" +
            "इशारे:\n" +
            "🖐️→✊ खुला हाथ वहीं रखकर उँगलियाँ जल्दी से नीचे मोड़ो = पिछला वीडियो\n" +
            "✊→🖐️ मुड़े हाथ को (थोड़ा रुककर) जल्दी से खोलो = अगला वीडियो\n" +
            "🔄 हाथ को घुमाओ: उँगलियाँ दाईं ओर से ऊपर होकर बाईं ओर = स्क्रीन बाएँ; उलटा = दाएँ\n" +
            "☝️ एक उँगली = गोल पॉइंटर चलाओ\n" +
            "🤏 अँगूठा उँगली से सटाओ (पिंच) = पॉइंटर की जगह टैप\n" +
            "👍 थम्स-अप 1 सेकंड से ज़्यादा = दो बार टैप (लाइक)\n" +
            "✊ कसकर मुट्ठी डेढ़ सेकंड = बैक\n" +
            "✌️ दो उँगलियाँ 1 सेकंड = होम\n" +
            "🖐️ हथेली ढाई सेकंड रोके रखो = प्ले/पॉज़\n"
        root.addView(tv)

        root.addView(makeButton("1) Accessibility खोलें") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(makeButton("2) App info (Restricted settings)") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })
        root.addView(makeButton("3) Hand Control शुरू करें") { startHand() })
        val prefs = getSharedPreferences("hc", MODE_PRIVATE)
        val swapBtn = Button(this)
        fun refreshSwap() {
            swapBtn.text = if (prefs.getBoolean("swap", false))
                "4) बाएँ-दाएँ दिशा: उलटी (बदलने के लिए दबाएँ)"
            else
                "4) बाएँ-दाएँ दिशा: सीधी (बदलने के लिए दबाएँ)"
        }
        refreshSwap()
        swapBtn.setOnClickListener {
            prefs.edit().putBoolean("swap", !prefs.getBoolean("swap", false)).apply()
            refreshSwap()
        }
        root.addView(swapBtn)
        root.addView(makeButton("बंद करें") {
            stopService(Intent(this, CameraService::class.java))
            Toast.makeText(this, "बंद हो गया", Toast.LENGTH_SHORT).show()
        })

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { onClick() }
        return b
    }

    private fun startHand() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            val perms = if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS)
            else arrayOf(Manifest.permission.CAMERA)
            requestPermissions(perms, 1)
            return
        }
        startForegroundService(Intent(this, CameraService::class.java))
        Toast.makeText(this, "चालू हो गया", Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startHand()
        }
    }
}

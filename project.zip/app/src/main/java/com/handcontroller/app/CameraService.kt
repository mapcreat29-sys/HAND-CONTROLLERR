package com.handcontroller.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraService : LifecycleService() {

    private lateinit var executor: ExecutorService
    private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    private var bitmapBuf: Bitmap? = null
    private val engine = GestureEngine()

    override fun onCreate() {
        super.onCreate()
        executor = Executors.newSingleThreadExecutor()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        startAsForeground()
        if (landmarker == null) {
            setupLandmarker()
            startCamera()
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val channelId = "hand_controller"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Hand Controller", NotificationManager.IMPORTANCE_LOW)
        )
        val n = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Hand Controller चालू है")
            .setContentText("कैमरा आपका हाथ देख रहा है")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(1, n)
        }
    }

    private fun setupLandmarker() {
        val base = BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build()
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setNumHands(1)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener { result, _ -> onResult(result) }
            .setErrorListener { }
            .build()
        landmarker = HandLandmarker.createFromOptions(this, opts)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val p = future.get()
            provider = p
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(480, 640))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(executor) { proxy -> analyze(proxy) }
            p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val lm = landmarker
        if (lm == null) {
            proxy.close()
            return
        }
        val w = proxy.width
        val h = proxy.height
        val rot = proxy.imageInfo.rotationDegrees
        val buf: Bitmap = bitmapBuf?.takeIf { it.width == w && it.height == h }
            ?: Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { bitmapBuf = it }
        try {
            buf.copyPixelsFromBuffer(proxy.planes[0].buffer)
        } finally {
            proxy.close()
        }
        val m = Matrix()
        m.postRotate(rot.toFloat())
        m.postScale(-1f, 1f) // सेल्फ़ी की तरह मिरर
        val rotated = Bitmap.createBitmap(buf, 0, 0, w, h, m, true)
        lm.detectAsync(BitmapImageBuilder(rotated).build(), SystemClock.uptimeMillis())
    }

    private fun onResult(r: HandLandmarkerResult) {
        val hands = r.landmarks()
        if (hands.isEmpty()) {
            engine.noHand()
        } else {
            engine.update(hands[0], SystemClock.uptimeMillis())
        }
    }

    override fun onDestroy() {
        provider?.unbindAll()
        landmarker?.close()
        landmarker = null
        executor.shutdown()
        HandControlService.instance?.hidePointer()
        super.onDestroy()
    }
}

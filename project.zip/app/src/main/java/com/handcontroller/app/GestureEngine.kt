package com.handcontroller.app

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs
import kotlin.math.hypot

class GestureEngine {

    private enum class Pose { NONE, PALM, FIST, POINT, PEACE, THUMB, PINCH }

    private data class Sample(val t: Long, val x: Float, val y: Float)

    private var pose = Pose.NONE
    private var poseSince = 0L
    private var fired = false
    private var lastAction = 0L
    private val hist = ArrayList<Sample>()
    private var px = 0.5f
    private var py = 0.5f

    fun noHand() {
        pose = Pose.NONE
        hist.clear()
        HandControlService.instance?.hidePointer()
    }

    private fun d(a: NormalizedLandmark, b: NormalizedLandmark): Float =
        hypot(a.x() - b.x(), a.y() - b.y())

    private fun classify(l: List<NormalizedLandmark>): Pose {
        val w = l[0]
        val idx = d(l[8], w) > d(l[6], w)
        val mid = d(l[12], w) > d(l[10], w)
        val ring = d(l[16], w) > d(l[14], w)
        val pnk = d(l[20], w) > d(l[18], w)
        val thumbOut = d(l[4], l[17]) > d(l[3], l[17]) * 1.15f
        val size = d(l[0], l[9])
        val pinch = d(l[4], l[8]) < size * 0.3f && d(l[8], w) > size
        val thumbUp = thumbOut && l[4].y() < l[3].y() && l[3].y() < l[2].y()

        return when {
            pinch -> Pose.PINCH
            idx && mid && ring && pnk -> Pose.PALM
            !idx && !mid && !ring && !pnk -> if (thumbUp) Pose.THUMB else Pose.FIST
            idx && !mid && !ring && !pnk -> Pose.POINT
            idx && mid && !ring && !pnk -> Pose.PEACE
            else -> Pose.NONE
        }
    }

    private fun fire(now: Long) {
        fired = true
        lastAction = now
    }

    fun update(l: List<NormalizedLandmark>, now: Long) {
        val newPose = classify(l)
        if (newPose != pose) {
            pose = newPose
            poseSince = now
            fired = false
        }
        val svc = HandControlService.instance ?: return
        val held = now - poseSince

        // पॉइंटर
        if (pose == Pose.POINT) {
            val tx = ((l[8].x() - 0.15f) / 0.7f).coerceIn(0f, 1f)
            val ty = ((l[8].y() - 0.15f) / 0.7f).coerceIn(0f, 1f)
            px += (tx - px) * 0.35f
            py += (ty - py) * 0.35f
            svc.movePointer(px, py)
        } else if (pose != Pose.PINCH) {
            svc.hidePointer()
        }

        // स्वाइप (खुला हाथ)
        if (pose == Pose.PALM) {
            hist.add(Sample(now, l[9].x(), l[9].y()))
            while (hist.isNotEmpty() && now - hist[0].t > 450) hist.removeAt(0)
            if (hist.size >= 4 && now - lastAction > 900) {
                val dy = hist.last().y - hist.first().y
                val dx = hist.last().x - hist.first().x
                if (abs(dy) > 0.22f && abs(dy) > abs(dx) * 1.5f) {
                    svc.swipe(dy < 0)
                    hist.clear()
                    fire(now)
                }
            }
        } else {
            hist.clear()
        }

        // रोककर रखने वाले / एक बार वाले इशारे
        if (!fired && now - lastAction > 900) {
            when (pose) {
                Pose.PINCH -> if (held > 150) { svc.tapAt(px, py); fire(now) }
                Pose.THUMB -> if (held > 400) { svc.doubleTapCenter(); fire(now) }
                Pose.FIST -> if (held > 1000) { svc.goBack(); fire(now) }
                Pose.PEACE -> if (held > 1000) { svc.goHome(); fire(now) }
                Pose.PALM -> if (held > 1800) { svc.tapAt(0.5f, 0.5f); fire(now) }
                else -> {}
            }
        }
    }
}

package com.handcontroller.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.PixelFormat
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class HandControlService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: HandControlService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var pointer: View? = null
    private var lp: WindowManager.LayoutParams? = null

    private fun sw() = resources.displayMetrics.widthPixels.toFloat()
    private fun sh() = resources.displayMetrics.heightPixels.toFloat()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        hidePointer()
        return super.onUnbind(intent)
    }

    // ---------- पॉइंटर ----------
    private fun ensurePointer() {
        if (pointer != null) return
        val v = View(this)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0xAAFF3B30.toInt())
        bg.setStroke(4, 0xFFFFFFFF.toInt())
        v.background = bg
        val p = WindowManager.LayoutParams(
            60, 60,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        wm?.addView(v, p)
        pointer = v
        lp = p
    }

    fun movePointer(nx: Float, ny: Float) {
        main.post {
            ensurePointer()
            val p = lp ?: return@post
            p.x = (nx * sw()).toInt() - 30
            p.y = (ny * sh()).toInt() - 30
            pointer?.let { wm?.updateViewLayout(it, p) }
        }
    }

    fun hidePointer() {
        main.post {
            pointer?.let {
                try { wm?.removeView(it) } catch (e: Exception) { }
            }
            pointer = null
            lp = null
        }
    }

    // ---------- एक्शन ----------
    fun tapAt(nx: Float, ny: Float) {
        main.post {
            val path = Path()
            path.moveTo(nx * sw(), ny * sh())
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                .build()
            dispatchGesture(g, null, null)
        }
    }

    fun doubleTapCenter() {
        main.post {
            val path = Path()
            path.moveTo(sw() / 2f, sh() / 2f)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
                .addStroke(GestureDescription.StrokeDescription(path, 140, 50))
                .build()
            dispatchGesture(g, null, null)
        }
    }

    // up = true  -> स्क्रीन पर उँगली नीचे से ऊपर (अगला वीडियो)
    fun swipe(up: Boolean) {
        main.post {
            val path = Path()
            val x = sw() / 2f
            val from = if (up) sh() * 0.72f else sh() * 0.28f
            val to = if (up) sh() * 0.28f else sh() * 0.72f
            path.moveTo(x, from)
            path.lineTo(x, to)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 220))
                .build()
            dispatchGesture(g, null, null)
        }
    }

    fun goBack() {
        main.post { performGlobalAction(GLOBAL_ACTION_BACK) }
    }

    fun goHome() {
        main.post { performGlobalAction(GLOBAL_ACTION_HOME) }
    }
}

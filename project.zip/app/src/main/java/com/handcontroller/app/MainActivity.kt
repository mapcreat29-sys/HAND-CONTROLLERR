package com.handcontroller.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val tv = TextView(this)
        tv.textSize = 16f
        tv.text = "Hand Controller\n\n" +
            "पहले ये करें:\n" +
            "1) नीचे बटन 2 दबाकर App info में ऊपर दाईं ⋮ से \"Allow restricted settings\" चुनें (अगर दिखे)।\n" +
            "2) बटन 1 दबाकर Accessibility में Hand Controller को चालू करें।\n" +
            "3) बटन 3 दबाएँ और कैमरा permission दें।\n" +
            "4) फ़ोन को सामने टिकाकर रखें, ताकि फ्रंट कैमरे को हाथ दिखे।\n\n" +
            "इशारे:\n" +
            "✋ खुला हाथ ऊपर/नीचे स्वाइप = अगला/पिछला वीडियो\n" +
            "☝️ एक उँगली = पॉइंटर चलाओ\n" +
            "🤏 पिंच = टैप\n" +
            "👍 थम्स-अप = दो बार टैप (लाइक)\n" +
            "✊ मुट्ठी 1 सेकंड = बैक\n" +
            "✌️ दो उँगलियाँ 1 सेकंड = होम\n" +
            "🖐️ हथेली रोके रखो = प्ले/पॉज़\n"
        root.addView(tv)

        root.addView(makeButton("1) Accessibility खोलें") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(makeButton("2) App info (Restricted settings)") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })
        root.addView(makeButton("3) Hand Control शुरू करें") { startHand() })
        root.addView(makeButton("बंद करें") {
            stopService(Intent(this, CameraService::class.java))
            Toast.makeText(this, "बंद हो गया", Toast.LENGTH_SHORT).show()
        })

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { onClick() }
        return b
    }

    private fun startHand() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            val perms = if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS)
            else arrayOf(Manifest.permission.CAMERA)
            requestPermissions(perms, 1)
            return
        }
        startForegroundService(Intent(this, CameraService::class.java))
        Toast.makeText(this, "चालू हो गया", Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startHand()
        }
    }
}
